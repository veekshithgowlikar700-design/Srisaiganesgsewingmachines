# One-click APK

After pushing to GitHub:
- Actions
- Build Android APK
- Run workflow

The workflow uses Gradle 8.9 and JDK 17 on GitHub's Ubuntu runner.
The generated APK is an unsigned debug APK suitable for direct installation/testing.

For Play Store release, add a signing key and a release workflow later.
